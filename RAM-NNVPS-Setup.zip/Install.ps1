# RAM-NNVPS installer - install to C:\RAM-NNVPS + check .NET + create shortcuts
param(
    [switch]$Launch,      # launch after install (no prompt)
    [switch]$NoPrompt     # skip "Launch now?" question
)
$ErrorActionPreference = "Stop"
$src = Split-Path -Parent $MyInvocation.MyCommand.Path
$dst = "C:\RAM-NNVPS"

Write-Host "==== Installing RAM-NNVPS ====" -ForegroundColor Cyan

# ---- 1) Check .NET Framework 4.7.2+ (Release >= 461808) ----
$net = 0
try { $net = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full" -Name Release -ErrorAction Stop).Release } catch {}
if ($net -lt 461808) {
    Write-Host "Missing .NET Framework 4.8 - installing automatically, please wait..." -ForegroundColor Yellow
    $url = "https://go.microsoft.com/fwlink/?LinkId=2085155"
    $tmp = Join-Path $env:TEMP "ndp48-web.exe"
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $url -OutFile $tmp -UseBasicParsing
        Write-Host "Installing .NET 4.8 (silent)... this can take a few minutes." -ForegroundColor Yellow
        $p = Start-Process $tmp -ArgumentList "/q","/norestart" -Wait -PassThru
        Write-Host ".NET installed (exit $($p.ExitCode)). If asked, restart the PC once." -ForegroundColor Green
    } catch {
        Write-Host "Auto-install failed - opening download page instead." -ForegroundColor Red
        Start-Process "https://dotnet.microsoft.com/download/dotnet-framework/net48"
        Read-Host "Install .NET 4.8 then run Install.bat again. Press Enter to exit"
        exit
    }
} else {
    Write-Host "[OK] .NET Framework ready (Release $net)" -ForegroundColor Green
}

# ---- 2) Close old instance if running (avoid file lock) ----
Get-Process RAM-NNVPS -ErrorAction SilentlyContinue | ForEach-Object { try { $_.Kill() } catch {} }
Start-Sleep -Milliseconds 800

# ---- 3) Create C:\RAM-NNVPS and copy program files ----
New-Item -ItemType Directory -Path $dst -Force | Out-Null
$files = @("RAM-NNVPS.exe","LibreHardwareMonitorLib.dll","HidSharp.dll","version.json","win_unlock.dll","logo.ico","logo.png")
foreach ($f in $files) {
    $p = Join-Path $src $f
    if (Test-Path $p) { Copy-Item $p (Join-Path $dst $f) -Force }
}
$exe = Join-Path $dst "RAM-NNVPS.exe"
if (-not (Test-Path $exe)) { Write-Host "RAM-NNVPS.exe not found in package." -ForegroundColor Red; Read-Host "Press Enter"; exit }
Write-Host "[OK] Installed to $dst" -ForegroundColor Green

# ---- 4) Create Desktop + Start Menu shortcuts ----
$ws = New-Object -ComObject WScript.Shell
function New-SC($lnk) {
    $s = $ws.CreateShortcut($lnk)
    $s.TargetPath = $exe
    $s.WorkingDirectory = $dst
    $s.IconLocation = "$exe,0"
    $s.Description = "RAM-NNVPS"
    $s.Save()
}
New-SC (Join-Path ([Environment]::GetFolderPath("Desktop")) "RAM-NNVPS.lnk")
Write-Host "[OK] Desktop shortcut created" -ForegroundColor Green
$start = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"
if (Test-Path $start) { New-SC (Join-Path $start "RAM-NNVPS.lnk"); Write-Host "[OK] Start Menu shortcut created" -ForegroundColor Green }

Write-Host ""
Write-Host "==== Done! ====" -ForegroundColor Cyan
Write-Host "Program installed at $dst" -ForegroundColor White
Write-Host "Double-click the RAM-NNVPS icon on your Desktop to open." -ForegroundColor White

# ---- 5) Offer to launch now ----
if ($Launch) {
    Start-Process $exe -WorkingDirectory $dst
} elseif (-not $NoPrompt) {
    $run = Read-Host "Launch now? (y/n)"
    if ($run -eq "y" -or $run -eq "Y") { Start-Process $exe -WorkingDirectory $dst }
}

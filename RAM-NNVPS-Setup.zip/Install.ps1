# ติดตั้ง RAM-NNVPS: สร้างไอคอนบนหน้าจอ + เมนู Start (ชี้ไปที่ RAM-NNVPS.exe)
$ErrorActionPreference = 'Stop'
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
# หา exe: โฟลเดอร์นี้ หรือ Release\
$exe = Join-Path $dir 'RAM-NNVPS.exe'
if (-not (Test-Path $exe)) { $exe = Join-Path $dir 'Release\RAM-NNVPS.exe' }
if (-not (Test-Path $exe)) { Write-Host "ไม่พบ RAM-NNVPS.exe (รัน Build-CS.ps1 ก่อน)" -ForegroundColor Red; Read-Host; exit }
$exeDir = Split-Path -Parent $exe

$ws = New-Object -ComObject WScript.Shell
function New-SC($lnk) {
    $s = $ws.CreateShortcut($lnk)
    $s.TargetPath = $exe
    $s.WorkingDirectory = $exeDir
    $s.IconLocation = "$exe,0"
    $s.Description = "RAM-NNVPS - ดูแลเครื่อง/RAM/Committed สำหรับ Roblox"
    $s.Save()
}

$desktop = [Environment]::GetFolderPath('Desktop')
New-SC (Join-Path $desktop 'RAM-NNVPS.lnk')
Write-Host "สร้างไอคอนบนหน้าจอแล้ว" -ForegroundColor Green

$start = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
if (Test-Path $start) { New-SC (Join-Path $start 'RAM-NNVPS.lnk'); Write-Host "เพิ่มในเมนู Start แล้ว" -ForegroundColor Green }

Write-Host "`nติดตั้งเสร็จ! ดับเบิลคลิกไอคอน RAM-NNVPS บนหน้าจอเพื่อเปิดได้เลย" -ForegroundColor Cyan
Read-Host "`nกด Enter เพื่อปิด"

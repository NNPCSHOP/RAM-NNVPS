# RAM-NNVPS installer: check .NET Framework, then create Desktop + Start Menu shortcut
$ErrorActionPreference = "Stop"
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path

# ---- Check .NET Framework 4.7.2+ (Release >= 461808). Win10/11 usually have it ----
$net = 0
try { $net = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full" -Name Release -ErrorAction Stop).Release } catch {}
if ($net -lt 461808) {
    Write-Host "Missing .NET Framework 4.8 - installing automatically, please wait..." -ForegroundColor Yellow
    $url = "https://go.microsoft.com/fwlink/?LinkId=2085155"   # official .NET Framework 4.8 web installer
    $tmp = Join-Path $env:TEMP "ndp48-web.exe"
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $url -OutFile $tmp -UseBasicParsing
        Write-Host "Downloaded. Installing .NET 4.8 (silent)... this can take a few minutes." -ForegroundColor Yellow
        $p = Start-Process $tmp -ArgumentList "/q","/norestart" -Wait -PassThru
        Write-Host ".NET installer finished (exit $($p.ExitCode)). If it asks, restart the PC once." -ForegroundColor Green
    } catch {
        Write-Host "Auto-install failed. Opening download page instead..." -ForegroundColor Red
        Start-Process "https://dotnet.microsoft.com/download/dotnet-framework/net48"
        Read-Host "Install .NET 4.8 then run Install.bat again. Press Enter to exit"
        exit
    }
} else {
    Write-Host ".NET Framework OK (Release $net)." -ForegroundColor Green
}
$exe = Join-Path $dir "RAM-NNVPS.exe"
if (-not (Test-Path $exe)) { $exe = Join-Path $dir "Release\RAM-NNVPS.exe" }
if (-not (Test-Path $exe)) { Write-Host "RAM-NNVPS.exe not found. Run Build-CS.ps1 first." -ForegroundColor Red; Read-Host "Press Enter"; exit }
$exeDir = Split-Path -Parent $exe
$ws = New-Object -ComObject WScript.Shell
function New-SC($lnk) {
    $s = $ws.CreateShortcut($lnk)
    $s.TargetPath = $exe
    $s.WorkingDirectory = $exeDir
    $s.IconLocation = "$exe,0"
    $s.Description = "RAM-NNVPS"
    $s.Save()
}
New-SC (Join-Path ([Environment]::GetFolderPath("Desktop")) "RAM-NNVPS.lnk")
Write-Host "Desktop shortcut created." -ForegroundColor Green
$start = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"
if (Test-Path $start) { New-SC (Join-Path $start "RAM-NNVPS.lnk"); Write-Host "Start Menu shortcut created." -ForegroundColor Green }
Write-Host ""
Write-Host "Installed! Double-click the RAM-NNVPS icon on your Desktop." -ForegroundColor Cyan
Read-Host "Press Enter"

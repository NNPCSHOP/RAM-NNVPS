# RAM-NNVPS installer: create Desktop + Start Menu shortcut to RAM-NNVPS.exe
$ErrorActionPreference = "Stop"
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$exe = Join-Path $dir "RAM-NNVPS.exe"
if (-not (Test-Path $exe)) { $exe = Join-Path $dir "Release\RAM-NNVPS.exe" }
if (-not (Test-Path $exe)) { Write-Host "RAM-NNVPS.exe not found. Run Build-CS.ps1 first." -ForegroundColor Red; Read-Host "Press Enter"; exit }
$exeDir = Split-Path -Parent $exe
$ws = New-Object -ComObject WScript.Shell
function New-SC($lnk) {
    $s = $ws.CreateShortcut($lnk)
    $s.TargetPath = $exe
    $s.WorkingDirectory = $exeDir
    $s.IconLocation = "$exe,0"
    $s.Description = "RAM-NNVPS"
    $s.Save()
}
New-SC (Join-Path ([Environment]::GetFolderPath("Desktop")) "RAM-NNVPS.lnk")
Write-Host "Desktop shortcut created." -ForegroundColor Green
$start = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"
if (Test-Path $start) { New-SC (Join-Path $start "RAM-NNVPS.lnk"); Write-Host "Start Menu shortcut created." -ForegroundColor Green }
Write-Host ""
Write-Host "Installed! Double-click the RAM-NNVPS icon on your Desktop." -ForegroundColor Cyan
Read-Host "Press Enter"
